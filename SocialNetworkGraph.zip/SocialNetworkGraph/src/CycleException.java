
@SuppressWarnings("serial")
public class CycleException extends Exception {
	
}
